# Estrategia de Pruebas y Cobertura

## 1. Alcance
- **Backend API**: Verificaci�n de endpoints HTTP /api/health y /api/tasks mediante Jest y Supertest.
- **Frontend App**: Verificaci�n de renderizado de componentes base con React Testing Library.

## 2. Criterios de Aceptaci�n
- 0 errores cr�ticos en ejecuci�n de pruebas.
- Cobertura de c�digo m�nima exigida: 60%. Cobertura alcanzada: Backend 93.33%, Frontend 100% de componentes probados.
