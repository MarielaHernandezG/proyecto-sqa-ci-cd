# Plan de Aseguramiento de Calidad de Software (SQA)

## 1. Objetivos de Calidad
- Garantizar la estabilidad del software mediante pruebas automatizadas continuas (Backend >90% cobertura, Frontend >80% cobertura).
- Detectar vulnerabilidades y duplicaci�n de c�digo mediante el an�lisis est�tico de SonarCloud.

## 2. Est�ndares y Herramientas
- **Lenguajes**: JavaScript (Node.js/Express, React).
- **Pruebas Automatizadas**: Jest, Supertest, React Testing Library.
- **CI/CD**: GitHub Actions.
- **Calidad de C�digo**: SonarCloud.

## 3. Estrategia de Pruebas
- Pruebas unitarias y de integraci�n ejecutadas localmente antes de cada despliegue.
- Verificaci�n autom�tica en el pipeline CI/CD en cada push a la rama principal.
