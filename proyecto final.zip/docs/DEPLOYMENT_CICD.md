# Gu�a de Despliegue y Pipeline CI/CD

## 1. Flujo de Trabajo
1. Desarrollo de funcionalidades en subramas o repositorio local.
2. Ejecuci�n local de pruebas mediante 
pm test en backend y frontend.
3. Git Commit y Push a la rama principal (main/master).
4. GitHub Actions activa autom�ticamente el pipeline con 3 etapas:
   - Compilaci�n y pruebas de Backend.
   - Compilaci�n y pruebas de Frontend.
   - Escaneo est�tico con SonarCloud.
