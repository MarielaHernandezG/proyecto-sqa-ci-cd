const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'OK', message: 'Servidor SQA funcionando correctamente' });
});

app.get('/api/tasks', (req, res) => {
  res.status(200).json([
    { id: 1, title: 'Configurar Pipeline CI/CD', completed: true },
    { id: 2, title: 'Implementar SonarCloud', completed: false }
  ]);
});

app.post('/api/tasks', (req, res) => {
  const { title } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'El titulo es obligatorio' });
  }
  return res.status(201).json({ id: 3, title, completed: false });
});

module.exports = app;
