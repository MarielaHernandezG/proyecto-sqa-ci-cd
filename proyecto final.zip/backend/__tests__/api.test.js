const request = require('supertest');
const app = require('../app');

describe('Pruebas de Integracion y API - SQA', () => {
  it('Debe responder 200 OK en el endpoint de salud (/api/health)', async () => {
    const res = await request(app).get('/api/health');
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty('status', 'OK');
  });

  it('Debe obtener la lista de tareas correctamente (/api/tasks)', async () => {
    const res = await request(app).get('/api/tasks');
    expect(res.statusCode).toEqual(200);
    expect(Array.isArray(res.body)).toBeTruthy();
    expect(res.body.length).toBeGreaterThan(0);
  });

  it('Debe rechazar la creacion de tareas sin titulo', async () => {
    const res = await request(app).post('/api/tasks').send({});
    expect(res.statusCode).toEqual(400);
    expect(res.body).toHaveProperty('error');
  });
});
