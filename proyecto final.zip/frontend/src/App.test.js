import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import App from './App';

test('Renderiza el titulo principal del proyecto SQA', () => {
  render(<App />);
  const titleElement = screen.getByText(/Proyecto SQA - CI\/CD Pipeline/i);
  expect(titleElement).toBeInTheDocument();
});
