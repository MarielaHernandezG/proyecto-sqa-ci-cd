import React from 'react';

function App() {
  return (
    <div className="App">
      <h1>Proyecto SQA - CI/CD Pipeline</h1>
      <p>Sistema de Gesti�n con Aseguramiento de Calidad Integrado</p>
    </div>
  );
}

export default App;
